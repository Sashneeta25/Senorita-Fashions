﻿Public Class frm_customers_a174559
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_customers_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim mysql As String = "select * from TBL_CUSTOMER_A174559 ORDER BY FLD_CUST_ID ASC"
        Dim mytable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mytable)
        grd_customers.DataSource = mytable
    End Sub
End Class