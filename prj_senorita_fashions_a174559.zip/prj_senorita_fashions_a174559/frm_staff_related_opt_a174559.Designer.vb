﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_staff_related_opt_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_staff_related_opt_a174559))
        Me.btn_staffs = New System.Windows.Forms.Button()
        Me.btn_insert_staffs = New System.Windows.Forms.Button()
        Me.btn_update_delete_staffs = New System.Windows.Forms.Button()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_staffs
        '
        Me.btn_staffs.BackColor = System.Drawing.Color.Pink
        Me.btn_staffs.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staffs.ForeColor = System.Drawing.Color.Black
        Me.btn_staffs.Location = New System.Drawing.Point(592, 77)
        Me.btn_staffs.Name = "btn_staffs"
        Me.btn_staffs.Size = New System.Drawing.Size(345, 53)
        Me.btn_staffs.TabIndex = 8
        Me.btn_staffs.Text = "Staffs List"
        Me.btn_staffs.UseVisualStyleBackColor = False
        '
        'btn_insert_staffs
        '
        Me.btn_insert_staffs.BackColor = System.Drawing.Color.Pink
        Me.btn_insert_staffs.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insert_staffs.ForeColor = System.Drawing.Color.Black
        Me.btn_insert_staffs.Location = New System.Drawing.Point(592, 155)
        Me.btn_insert_staffs.Name = "btn_insert_staffs"
        Me.btn_insert_staffs.Size = New System.Drawing.Size(345, 53)
        Me.btn_insert_staffs.TabIndex = 12
        Me.btn_insert_staffs.Text = "Insert New Staffs"
        Me.btn_insert_staffs.UseVisualStyleBackColor = False
        '
        'btn_update_delete_staffs
        '
        Me.btn_update_delete_staffs.BackColor = System.Drawing.Color.Pink
        Me.btn_update_delete_staffs.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update_delete_staffs.Location = New System.Drawing.Point(592, 233)
        Me.btn_update_delete_staffs.Name = "btn_update_delete_staffs"
        Me.btn_update_delete_staffs.Size = New System.Drawing.Size(345, 53)
        Me.btn_update_delete_staffs.TabIndex = 13
        Me.btn_update_delete_staffs.Text = "Update/Delete Staffs"
        Me.btn_update_delete_staffs.UseVisualStyleBackColor = False
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.Yellow
        Me.btn_back.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(821, 487)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(145, 45)
        Me.btn_back.TabIndex = 14
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_staff_related_opt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(978, 544)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_update_delete_staffs)
        Me.Controls.Add(Me.btn_insert_staffs)
        Me.Controls.Add(Me.btn_staffs)
        Me.MaximizeBox = False
        Me.Name = "frm_staff_related_opt"
        Me.Text = "SENORITA FASHIONS- RELATED OPTIONS (STAFFS)"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_staffs As Button
    Friend WithEvents btn_insert_staffs As Button
    Friend WithEvents btn_update_delete_staffs As Button
    Friend WithEvents btn_back As Button
End Class
