﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_odr_related_opt_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_odr_related_opt_a174559))
        Me.btn_order_list = New System.Windows.Forms.Button()
        Me.btn_order_details = New System.Windows.Forms.Button()
        Me.btn_make_order = New System.Windows.Forms.Button()
        Me.btn_invoice = New System.Windows.Forms.Button()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_order_list
        '
        Me.btn_order_list.BackColor = System.Drawing.Color.Yellow
        Me.btn_order_list.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_order_list.Location = New System.Drawing.Point(24, 46)
        Me.btn_order_list.Name = "btn_order_list"
        Me.btn_order_list.Size = New System.Drawing.Size(345, 53)
        Me.btn_order_list.TabIndex = 7
        Me.btn_order_list.Text = "Orders List"
        Me.btn_order_list.UseVisualStyleBackColor = False
        '
        'btn_order_details
        '
        Me.btn_order_details.BackColor = System.Drawing.Color.Yellow
        Me.btn_order_details.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_order_details.Location = New System.Drawing.Point(24, 123)
        Me.btn_order_details.Name = "btn_order_details"
        Me.btn_order_details.Size = New System.Drawing.Size(345, 53)
        Me.btn_order_details.TabIndex = 8
        Me.btn_order_details.Text = "Order Details"
        Me.btn_order_details.UseVisualStyleBackColor = False
        '
        'btn_make_order
        '
        Me.btn_make_order.BackColor = System.Drawing.Color.Yellow
        Me.btn_make_order.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_make_order.Location = New System.Drawing.Point(24, 200)
        Me.btn_make_order.Name = "btn_make_order"
        Me.btn_make_order.Size = New System.Drawing.Size(345, 53)
        Me.btn_make_order.TabIndex = 9
        Me.btn_make_order.Text = "Make Order "
        Me.btn_make_order.UseVisualStyleBackColor = False
        '
        'btn_invoice
        '
        Me.btn_invoice.BackColor = System.Drawing.Color.Yellow
        Me.btn_invoice.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_invoice.Location = New System.Drawing.Point(24, 277)
        Me.btn_invoice.Name = "btn_invoice"
        Me.btn_invoice.Size = New System.Drawing.Size(345, 53)
        Me.btn_invoice.TabIndex = 10
        Me.btn_invoice.Text = "Invoice"
        Me.btn_invoice.UseVisualStyleBackColor = False
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.Yellow
        Me.btn_back.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(821, 487)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(145, 45)
        Me.btn_back.TabIndex = 11
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_odr_related_opt_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(978, 544)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_invoice)
        Me.Controls.Add(Me.btn_make_order)
        Me.Controls.Add(Me.btn_order_details)
        Me.Controls.Add(Me.btn_order_list)
        Me.MaximizeBox = False
        Me.Name = "frm_odr_related_opt_a174559"
        Me.Text = "SENORITA FASHIONS- RELATED OPTIONS (ORDERS)"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_order_list As Button
    Friend WithEvents btn_order_details As Button
    Friend WithEvents btn_make_order As Button
    Friend WithEvents btn_invoice As Button
    Friend WithEvents btn_back As Button
End Class
