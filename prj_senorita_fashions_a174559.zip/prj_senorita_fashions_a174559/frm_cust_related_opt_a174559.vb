﻿Public Class frm_cust_related_opt_a174559
    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        Me.Close()
        frm_main_menu_a174559.Show()
    End Sub

    Private Sub btn_customers_Click(sender As Object, e As EventArgs) Handles btn_customers_list.Click
        frm_customers_a174559.Show()
    End Sub

    Private Sub btn_insert_customers_Click(sender As Object, e As EventArgs) Handles btn_insert_customers.Click
        frm_insert_customers_a174559.Show()
    End Sub

    Private Sub btn_update_delete_customers_Click(sender As Object, e As EventArgs) Handles btn_update_delete_customers.Click
        frm_update_delete_customers_a174559.Show()
    End Sub
End Class