﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_main_menu_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_main_menu_a174559))
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.btn_products = New System.Windows.Forms.Button()
        Me.btn_customers = New System.Windows.Forms.Button()
        Me.btn_orders = New System.Windows.Forms.Button()
        Me.btn_staffs = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.Orange
        Me.lbl_title.Font = New System.Drawing.Font("Rockwell Condensed", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(525, 45)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(255, 56)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "MAIN MENU"
        '
        'lbl_date
        '
        Me.lbl_date.AutoSize = True
        Me.lbl_date.BackColor = System.Drawing.Color.Orange
        Me.lbl_date.Font = New System.Drawing.Font("Rockwell Condensed", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_date.Location = New System.Drawing.Point(12, 481)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(112, 42)
        Me.lbl_date.TabIndex = 1
        Me.lbl_date.Text = "Label1"
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.Color.Orange
        Me.btn_exit.Font = New System.Drawing.Font("Rockwell", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_exit.Location = New System.Drawing.Point(732, 477)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(234, 55)
        Me.btn_exit.TabIndex = 2
        Me.btn_exit.Text = "EXIT"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'btn_products
        '
        Me.btn_products.BackColor = System.Drawing.Color.DeepPink
        Me.btn_products.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_products.ForeColor = System.Drawing.Color.Black
        Me.btn_products.Location = New System.Drawing.Point(473, 151)
        Me.btn_products.Name = "btn_products"
        Me.btn_products.Size = New System.Drawing.Size(345, 53)
        Me.btn_products.TabIndex = 3
        Me.btn_products.Text = "Products"
        Me.btn_products.UseVisualStyleBackColor = False
        '
        'btn_customers
        '
        Me.btn_customers.BackColor = System.Drawing.Color.DeepPink
        Me.btn_customers.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customers.Location = New System.Drawing.Point(473, 273)
        Me.btn_customers.Name = "btn_customers"
        Me.btn_customers.Size = New System.Drawing.Size(345, 53)
        Me.btn_customers.TabIndex = 4
        Me.btn_customers.Text = "Customers"
        Me.btn_customers.UseVisualStyleBackColor = False
        '
        'btn_orders
        '
        Me.btn_orders.BackColor = System.Drawing.Color.Salmon
        Me.btn_orders.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_orders.ForeColor = System.Drawing.Color.Black
        Me.btn_orders.Location = New System.Drawing.Point(473, 334)
        Me.btn_orders.Name = "btn_orders"
        Me.btn_orders.Size = New System.Drawing.Size(345, 53)
        Me.btn_orders.TabIndex = 5
        Me.btn_orders.Text = "Orders"
        Me.btn_orders.UseVisualStyleBackColor = False
        '
        'btn_staffs
        '
        Me.btn_staffs.BackColor = System.Drawing.Color.Salmon
        Me.btn_staffs.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staffs.ForeColor = System.Drawing.Color.Black
        Me.btn_staffs.Location = New System.Drawing.Point(473, 212)
        Me.btn_staffs.Name = "btn_staffs"
        Me.btn_staffs.Size = New System.Drawing.Size(345, 53)
        Me.btn_staffs.TabIndex = 7
        Me.btn_staffs.Text = "Staffs"
        Me.btn_staffs.UseVisualStyleBackColor = False
        '
        'frm_main_menu_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(978, 544)
        Me.Controls.Add(Me.btn_staffs)
        Me.Controls.Add(Me.btn_orders)
        Me.Controls.Add(Me.btn_customers)
        Me.Controls.Add(Me.btn_products)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.lbl_date)
        Me.Controls.Add(Me.lbl_title)
        Me.MaximizeBox = False
        Me.Name = "frm_main_menu_a174559"
        Me.Text = "SENORITA FASHIONS-MAIN MENU"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents lbl_date As Label
    Friend WithEvents btn_exit As Button
    Friend WithEvents btn_products As Button
    Friend WithEvents btn_customers As Button
    Friend WithEvents btn_orders As Button
    Friend WithEvents btn_staffs As Button
End Class
