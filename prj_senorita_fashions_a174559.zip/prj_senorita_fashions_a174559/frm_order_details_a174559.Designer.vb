﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_order_details_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_order_details_a174559))
        Me.btn_close = New System.Windows.Forms.Button()
        Me.lbl_order_details = New System.Windows.Forms.Label()
        Me.grd_order_details = New System.Windows.Forms.DataGridView()
        CType(Me.grd_order_details, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Yellow
        Me.btn_close.Font = New System.Drawing.Font("Stencil", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(1002, 516)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(139, 46)
        Me.btn_close.TabIndex = 0
        Me.btn_close.Text = "CLOSE"
        Me.btn_close.UseVisualStyleBackColor = False
        '
        'lbl_order_details
        '
        Me.lbl_order_details.AutoSize = True
        Me.lbl_order_details.BackColor = System.Drawing.Color.Yellow
        Me.lbl_order_details.Font = New System.Drawing.Font("Stencil", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_order_details.Location = New System.Drawing.Point(424, 9)
        Me.lbl_order_details.Name = "lbl_order_details"
        Me.lbl_order_details.Size = New System.Drawing.Size(298, 43)
        Me.lbl_order_details.TabIndex = 1
        Me.lbl_order_details.Text = "ORDER DETAILS"
        '
        'grd_order_details
        '
        Me.grd_order_details.AllowUserToAddRows = False
        Me.grd_order_details.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_order_details.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_order_details.BackgroundColor = System.Drawing.Color.LightSalmon
        Me.grd_order_details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_order_details.Location = New System.Drawing.Point(30, 71)
        Me.grd_order_details.Name = "grd_order_details"
        Me.grd_order_details.ReadOnly = True
        Me.grd_order_details.RowHeadersWidth = 62
        Me.grd_order_details.RowTemplate.Height = 28
        Me.grd_order_details.Size = New System.Drawing.Size(1094, 439)
        Me.grd_order_details.TabIndex = 2
        '
        'frm_order_details_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1153, 574)
        Me.Controls.Add(Me.grd_order_details)
        Me.Controls.Add(Me.lbl_order_details)
        Me.Controls.Add(Me.btn_close)
        Me.MaximizeBox = False
        Me.Name = "frm_order_details_a174559"
        Me.Text = "SENORITA FASHIONS-ORDER DETAILS"
        CType(Me.grd_order_details, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_close As Button
    Friend WithEvents lbl_order_details As Label
    Friend WithEvents grd_order_details As DataGridView
End Class
