﻿Public Class frm_product_details_a174559
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        pic_product.BackgroundImage.Dispose()
        Me.Close()
    End Sub

    Private Sub frm_product_details_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim mysql As String = "select FLD_PRODUCT_ID from TBL_PRODUCTS_A174559 ORDER BY FLD_PRODUCT_ID ASC"
        Dim mytable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mytable)

        lst_product_id.DataSource = mytable
        lst_product_id.DisplayMember = "FLD_PRODUCT_ID"
        refresh_text(lst_product_id.Text)

    End Sub

    Private Sub refresh_text(product_id As String)
        Dim mysql As String = "select *from TBL_PRODUCTS_A174559 where FLD_PRODUCT_ID= '" & product_id & "'"
        Dim mytable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mytable)

        txt_product_name.Text = mytable.Rows(0).Item("FLD_PRODUCT_NAME")
        txt_price.Text = mytable.Rows(0).Item("FLD_PRICE")
        txt_material.Text = mytable.Rows(0).Item("FLD_MATERIAL")
        txt_style.Text = mytable.Rows(0).Item("FLD_STYLE")
        txt_ships_from.Text = mytable.Rows(0).Item("FLD_SHIPS_FROM")
        txt_quantity.Text = mytable.Rows(0).Item("FLD_QUANTITY")
        txt_type.Text = mytable.Rows(0).Item("FLD_TYPE")
        pic_product.BackgroundImage = Image.FromFile("pictures/" & product_id & ".jpg")
    End Sub



    Private Sub lst_product_id_MouseClick(sender As Object, e As MouseEventArgs) Handles lst_product_id.MouseClick
        refresh_text(lst_product_id.Text)
    End Sub

    Private Sub lst_product_id_KeyDown(sender As Object, e As KeyEventArgs) Handles lst_product_id.KeyDown
        refresh_text(lst_product_id.Text)
    End Sub

    Private Sub lst_product_id_KeyUp(sender As Object, e As KeyEventArgs) Handles lst_product_id.KeyUp
        refresh_text(lst_product_id.Text)
    End Sub

    Private Sub frm_product_details_a174559_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        pic_product.BackgroundImage.Dispose()
    End Sub
End Class