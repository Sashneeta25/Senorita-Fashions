﻿Imports System.ComponentModel

Public Class frm_insert_staffs_a174559
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_insert_staffs_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        refresh_grid()
    End Sub

    Private Sub refresh_grid()

        grd_staffs.DataSource = run_select("select * from TBL_STAFF_A174559 ORDER BY FLD_STAFF_ID ASC")

        txt_id.Text = generate_id()

        txt_name.Text = ""
        txt_contact.Text = ""
        txt_email.Text = ""

        If txt_name.Text = "" And txt_contact.Text = "" And txt_email.Text = "" Then
            btn_insert.Enabled = False
        End If

    End Sub
    Private Function generate_id() As String

        Dim lastid As String = run_select("select max(FLD_STAFF_ID) as maxID from TBL_STAFF_A174559").Rows(0).Item("maxID")

        'MsgBox(lastmatric)

        Dim newid As String = "S" & Mid(lastid, 2) + 1

        Return newid

    End Function
    Private Sub txt_name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_name.KeyPress
        If Not Char.IsLetter(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) And Not Char.IsWhiteSpace(e.KeyChar) Then
            btn_insert.Enabled = False
            MessageBox.Show("Please enter a valid name. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_name.ClearUndo()
        ElseIf Char.IsLetter(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If txt_name.Text = "" Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If

    End Sub
    Private Sub txt_name_Validating(sender As Object, e As CancelEventArgs) Handles txt_name.Validating
        If (txt_name.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_name_TextChanged(sender As Object, e As EventArgs) Handles txt_name.TextChanged
        If txt_name.Text = "" Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_contact_Click(sender As Object, e As EventArgs) Handles txt_contact.Click
        MessageBox.Show("Please enter a valid phone number of 10 or 11 digits")
        If txt_contact.Text = "" Or txt_email.Text = "" Or txt_name.Text = "" Then
            btn_insert.Enabled = False
        ElseIf txt_contact.Text.Length < 10 Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_contact_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_contact.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) Then
            btn_insert.Enabled = False
            MessageBox.Show("Please enter a valid phone number of 10 or 11 digits ONLY. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_contact.ClearUndo()
        ElseIf Char.IsNumber(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If txt_contact.Text.Length < 10 Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_contact_TextChanged(sender As Object, e As EventArgs) Handles txt_contact.TextChanged
        If txt_contact.Text = "" Then
            btn_insert.Enabled = False
        ElseIf Char.IsNumber(txt_contact.Text) Then
            If txt_contact.Text.Length < 10 Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_contact_Validating(sender As Object, e As CancelEventArgs) Handles txt_contact.Validating
        If txt_contact.Text = "" Then
            btn_insert.Enabled = False
        ElseIf Char.IsNumber(txt_contact.Text) Then
            If txt_contact.Text.Length < 10 Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_email_Click(sender As Object, e As EventArgs) Handles txt_email.Click
        If (txt_email.Text = "") Or txt_name.Text = "" Or txt_contact.Text = "" Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_email_TextChanged(sender As Object, e As EventArgs) Handles txt_email.TextChanged
        If (txt_email.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_email_Validating(sender As Object, e As CancelEventArgs) Handles txt_email.Validating
        If (txt_email.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click
        Dim mysql As String = "insert into TBL_STAFF_A174559 values ('" & txt_id.Text & "', '" & txt_name.Text & "', '" & txt_contact.Text & "', '" & txt_email.Text & "')"

        'MsgBox(mysql)
        Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2)

        Try

            mywriter.Connection.Open()
            mywriter.ExecuteNonQuery()
            mywriter.Connection.Close()

            refresh_grid()

        Catch ex As Exception
            Beep()
            MsgBox("There is a Mistake in the data that you entered as shown below: " & vbCrLf & vbCrLf & ex.Message)
            mywriter.Connection.Close()

        End Try

    End Sub
End Class