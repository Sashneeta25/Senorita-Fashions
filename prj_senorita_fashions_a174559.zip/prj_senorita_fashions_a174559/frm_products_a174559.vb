﻿Public Class frm_products_a174559
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_products_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim myconnection As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_SENORITA_FASHIONS_A174559.accdb;Persist Security Info=False;"
        Dim mysql As String = "select * from TBL_PRODUCTS_A174559 "
        Dim mytable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mytable)
        grd_products.DataSource = mytable
    End Sub
End Class