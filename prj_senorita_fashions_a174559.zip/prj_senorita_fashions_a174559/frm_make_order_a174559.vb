﻿Imports System.ComponentModel

Public Class frm_make_order_a174559
    Dim num As Integer
    Dim defaultpicture As String = Application.StartupPath & "\pictures\NoImage.jpg"
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        pic_product.BackgroundImage.Dispose()
        Me.Close()
    End Sub

    Private Sub frm_make_order_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim current_date As String = Date.Now
        refresh_grid()
        refresh_staff()
        refresh_customer()
        refresh_price()
        refresh_count()

        Dim mysql As String = "select FLD_PRODUCT_ID from TBL_PRODUCTS_A174559 ORDER BY FLD_PRODUCT_ID ASC"
        Dim mytable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mytable)

        lst_product_id.DataSource = mytable
        lst_product_id.DisplayMember = "FLD_PRODUCT_ID"
        refresh_text(lst_product_id.Text)
    End Sub
    Private Sub refresh_grid()
        grd_cart.ColumnCount = 6
        grd_cart.Columns(0).HeaderText = "PRODUCT ID"
        grd_cart.Columns(1).HeaderText = "STAFF ID"
        grd_cart.Columns(2).HeaderText = "CUSTOMER ID"
        grd_cart.Columns(3).HeaderText = "ORDER QUANTITY"
        grd_cart.Columns(4).HeaderText = "PRICE PER UNIT"
        grd_cart.Columns(5).HeaderText = "SUBTOTAL"




        refresh_count()
        refresh_staff()
        refresh_customer()
        refresh_price()


    End Sub

    Private Sub refresh_text(product_id As String)
        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A174559 WHERE FLD_PRODUCT_ID = '" & product_id & "'"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)

        txt_product_name.Text = mydatatable.Rows(0).Item("FLD_PRODUCT_NAME")
        txt_price.Text = mydatatable.Rows(0).Item("FLD_PRICE")
        txt_type.Text = mydatatable.Rows(0).Item("FLD_TYPE")


        'txt_grand_totals.Text = num * txt_price.Text

        Try

            pic_product.BackgroundImage = Image.FromFile("pictures/" & product_id & ".jpg")

        Catch ex As Exception

            pic_product.BackgroundImage = Image.FromFile("\pictures\NoImage.jpg")

        End Try
    End Sub
    Private Sub refresh_count()

        Dim count As Integer = 1
        Dim mysql As String = "SELECT COUNT(FLD_ODR_ID) As COUNT_ID FROM TBL_ORDER_A174559"

        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)

        count += mydatatable.Rows(0).Item("COUNT_ID")
        txt_order_id.Text = "SF" + count.ToString("000")

    End Sub
    Private Sub refresh_price()

        If grd_cart.RowCount > 0 Then
            Dim subtotal As Double
            subtotal = 0

            For index As Integer = 0 To grd_cart.RowCount - 1
                subtotal += Convert.ToDouble(grd_cart.Rows(index).Cells(5).Value)
            Next

            txt_grand_totals.Text = subtotal

        ElseIf grd_cart.RowCount = 0 Then

            txt_grand_totals.Text = "0.00"

        End If

    End Sub
    Private Sub refresh_staff()

        Dim mysql As String = "SELECT FLD_STAFF_ID FROM TBL_STAFF_A174559 ORDER BY FLD_STAFF_ID"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        cmb_staffid.DataSource = mydatatable
        cmb_staffid.DisplayMember = "FLD_STAFF_ID"

    End Sub

    Private Sub refresh_customer()

        Dim mysql As String = "SELECT FLD_CUST_ID FROM TBL_CUSTOMER_A174559 ORDER BY FLD_CUST_ID"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        cmb_custid.DataSource = mydatatable
        cmb_custid.DisplayMember = "FLD_CUST_ID"

    End Sub
    Private Sub refresh_order_details()

        Dim mytransaction As OleDb.OleDbTransaction
        myconnection2.Open()

        mytransaction = myconnection2.BeginTransaction
        Try

            For i As Integer = 0 To grd_cart.RowCount - 1
                'Dim odr_id As String = grd_cart(0, i).Value
                Dim product_id As String = grd_cart(0, i).Value
                Dim odr_quantity As String = grd_cart(3, i).Value
                Dim price_per_unit As String = grd_cart(4, i).Value
                Dim SubTotal As String = grd_cart(5, i).Value

                Dim mysql As String = "INSERT INTO TBL_ORDER_DETAILS_A174559(FLD_ODR_ID, FLD_PRODUCT_ID, FLD_PRICE_PER_UNIT, FLD_ODR_QUANTITY) values  ('" & txt_order_id.Text & "', '" & product_id & "', " & price_per_unit & "," & odr_quantity & ")"
                Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2, mytransaction)
                mywriter.ExecuteNonQuery()

            Next
            mytransaction.Commit()
            myconnection2.Close()
            'Beep()
            refresh_grid()
            'grd_cart.Rows.Clear()
            txt_grand_totals.Text = num * txt_price.Text

        Catch ex As Exception
            Beep()
            MsgBox("Problem with transaction:" & vbCrLf & vbCrLf & ex.Message)
            mytransaction.Rollback()
            myconnection2.Close()
            refresh_grid()

        End Try
        nup1.Value = 1
        txt_grand_totals.Text = "0"
        refresh_count()
    End Sub
    Private Sub refresh_order()

        Dim mytransaction As OleDb.OleDbTransaction
        myconnection2.Open()
        mytransaction = myconnection2.BeginTransaction
        Try

            Dim mysql As String = "INSERT INTO TBL_ORDER_A174559 (FLD_ODR_ID, FLD_ODR_DATE_TIME, FLD_STAFF_ID, FLD_CUST_ID) values  ('" & txt_order_id.Text & "', '" & Date.Now & "', '" & cmb_staffid.Text & "', '" & cmb_custid.Text & "')"

            Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2, mytransaction)

            mywriter.ExecuteNonQuery()
            mytransaction.Commit()
            myconnection2.Close()
            'Beep()
            'refresh_grid()

        Catch ex As Exception

            Beep()
            MsgBox("Problem with transaction:" & vbCrLf & vbCrLf & ex.Message)
            mytransaction.Rollback()
            myconnection2.Close()
            refresh_grid()

        End Try

    End Sub

    Private Sub btn_add_cart_Click(sender As Object, e As EventArgs) Handles btn_add_cart.Click


        Dim x = txt_price.Text * nup1.Value


        grd_cart.Rows.Add(New String() {lst_product_id.Text, cmb_staffid.Text, cmb_custid.Text, nup1.Value, txt_price.Text, x})

        nup1.Value = 1
        refresh_price()

    End Sub

    Private Sub btn_confirm_Click(sender As Object, e As EventArgs) Handles btn_confirm.Click
        Try
            If grd_cart.RowCount = 0 Then
                btn_confirm.Enabled = False
                MsgBox("Empty Transaction is NOT accepted. Please add items to cart and perform proper transaction.")
            Else
                refresh_order()
                refresh_order_details()
                Beep()
                MsgBox("Transaction Successful")
                txt_product_name.Text = ""
                txt_type.Text = ""
                txt_price.Text = ""
                lst_product_id.ClearSelected()
                pic_product.BackgroundImage = Image.FromFile(defaultpicture)
                grd_cart.Rows.Clear()
            End If
            btn_confirm.Enabled = True

        Catch ex As Exception
            MsgBox("Problem with transaction:" & vbCrLf & vbCrLf & ex.Message)
        End Try

    End Sub
    Private Sub btn_remove_Click(sender As Object, e As EventArgs) Handles btn_remove.Click

        Dim delete_order = MsgBox("Are you sure you want to remove this item from the cart?", MsgBoxStyle.YesNo)
        Try
            If delete_order = MsgBoxResult.Yes Then
                grd_cart.Rows.Remove(grd_cart.CurrentRow)
                refresh_price()

            Else
                refresh_price()

            End If
        Catch ex As Exception
            MsgBox("Error in deleting item from cart " & vbCrLf & vbCrLf & ex.Message)
        End Try


    End Sub
    Private Sub lst_product_id_MouseClick(sender As Object, e As MouseEventArgs) Handles lst_product_id.MouseClick
        refresh_text(lst_product_id.Text)
    End Sub

    Private Sub lst_product_id_KeyDown(sender As Object, e As KeyEventArgs) Handles lst_product_id.KeyDown
        refresh_text(lst_product_id.Text)
    End Sub

    Private Sub lst_product_id_KeyUp(sender As Object, e As KeyEventArgs) Handles lst_product_id.KeyUp
        refresh_text(lst_product_id.Text)
    End Sub

    Private Sub frm_make_order_a174559_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        pic_product.BackgroundImage.Dispose()
    End Sub

    Private Sub btn_add_cart_Validating(sender As Object, e As CancelEventArgs) Handles btn_add_cart.Validating
        If grd_cart.Rows.Count > 1 Then
            For i As Integer = 0 To grd_cart.Rows.Count - 1
                For j As Integer = i + 1 To grd_cart.Rows.Count - 1
                    If grd_cart.Rows(i).Cells(0).Value = grd_cart.Rows(j).Cells(0).Value Then
                        MsgBox("This item is already added to cart!  ")
                        grd_cart.Rows.RemoveAt(j)
                        btn_add_cart.Enabled = False
                        refresh_price()

                    End If
                Next
            Next
        End If
        btn_add_cart.Enabled = True

        If grd_cart.Rows.Count > 1 Then
            For i As Integer = 0 To grd_cart.Rows.Count - 1
                For j As Integer = i + 1 To grd_cart.Rows.Count - 1
                    If grd_cart.Rows(i).Cells(1).Value IsNot grd_cart.Rows(j).Cells(1).Value Then
                        MsgBox("INVALID STAFF ID. Only ONE Staff can Handle One Order At a Time.")
                        grd_cart.Rows.RemoveAt(j)
                        btn_add_cart.Enabled = False
                        refresh_price()

                    End If
                Next
            Next
        End If
        btn_add_cart.Enabled = True

        If grd_cart.Rows.Count > 1 Then
            For i As Integer = 0 To grd_cart.Rows.Count - 1
                For j As Integer = i + 1 To grd_cart.Rows.Count - 1
                    If grd_cart.Rows(i).Cells(2).Value IsNot grd_cart.Rows(j).Cells(2).Value Then
                        MsgBox("INVALID CUSTOMER ID. Only ONE Customer can make One Order At a Time.")
                        grd_cart.Rows.RemoveAt(j)
                        btn_add_cart.Enabled = False
                        refresh_price()

                    End If
                Next
            Next
        End If
        btn_add_cart.Enabled = True
    End Sub

End Class
