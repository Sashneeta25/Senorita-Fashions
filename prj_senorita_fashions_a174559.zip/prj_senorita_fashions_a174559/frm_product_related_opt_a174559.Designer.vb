﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_product_related_opt_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_product_related_opt_a174559))
        Me.btn_back = New System.Windows.Forms.Button()
        Me.btn_product_details = New System.Windows.Forms.Button()
        Me.btn_insert_products = New System.Windows.Forms.Button()
        Me.btn_update_delete_products = New System.Windows.Forms.Button()
        Me.btn_products = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.Yellow
        Me.btn_back.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(821, 487)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(145, 45)
        Me.btn_back.TabIndex = 2
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'btn_product_details
        '
        Me.btn_product_details.BackColor = System.Drawing.Color.Cyan
        Me.btn_product_details.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_product_details.Location = New System.Drawing.Point(579, 98)
        Me.btn_product_details.Name = "btn_product_details"
        Me.btn_product_details.Size = New System.Drawing.Size(345, 53)
        Me.btn_product_details.TabIndex = 9
        Me.btn_product_details.Text = "Products Catalog"
        Me.btn_product_details.UseVisualStyleBackColor = False
        '
        'btn_insert_products
        '
        Me.btn_insert_products.BackColor = System.Drawing.Color.Cyan
        Me.btn_insert_products.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insert_products.Location = New System.Drawing.Point(579, 157)
        Me.btn_insert_products.Name = "btn_insert_products"
        Me.btn_insert_products.Size = New System.Drawing.Size(345, 53)
        Me.btn_insert_products.TabIndex = 10
        Me.btn_insert_products.Text = "Insert New Products"
        Me.btn_insert_products.UseVisualStyleBackColor = False
        '
        'btn_update_delete_products
        '
        Me.btn_update_delete_products.BackColor = System.Drawing.Color.Cyan
        Me.btn_update_delete_products.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update_delete_products.ForeColor = System.Drawing.Color.Black
        Me.btn_update_delete_products.Location = New System.Drawing.Point(579, 216)
        Me.btn_update_delete_products.Name = "btn_update_delete_products"
        Me.btn_update_delete_products.Size = New System.Drawing.Size(345, 53)
        Me.btn_update_delete_products.TabIndex = 11
        Me.btn_update_delete_products.Text = "Update/Delete Products"
        Me.btn_update_delete_products.UseVisualStyleBackColor = False
        '
        'btn_products
        '
        Me.btn_products.BackColor = System.Drawing.Color.Cyan
        Me.btn_products.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_products.ForeColor = System.Drawing.Color.Black
        Me.btn_products.Location = New System.Drawing.Point(579, 39)
        Me.btn_products.Name = "btn_products"
        Me.btn_products.Size = New System.Drawing.Size(345, 53)
        Me.btn_products.TabIndex = 12
        Me.btn_products.Text = "Products List"
        Me.btn_products.UseVisualStyleBackColor = False
        '
        'frm_product_related_opt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(978, 544)
        Me.Controls.Add(Me.btn_products)
        Me.Controls.Add(Me.btn_update_delete_products)
        Me.Controls.Add(Me.btn_insert_products)
        Me.Controls.Add(Me.btn_product_details)
        Me.Controls.Add(Me.btn_back)
        Me.MaximizeBox = False
        Me.Name = "frm_product_related_opt"
        Me.Text = "SENORITA FASHIONS- RELATED OPTIONS (PRODUCTS)"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_back As Button
    Friend WithEvents btn_product_details As Button
    Friend WithEvents btn_insert_products As Button
    Friend WithEvents btn_update_delete_products As Button
    Friend WithEvents btn_products As Button
End Class
