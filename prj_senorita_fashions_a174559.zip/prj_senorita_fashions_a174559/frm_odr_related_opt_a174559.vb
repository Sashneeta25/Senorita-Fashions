﻿Public Class frm_odr_related_opt_a174559
    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        Me.Close()
        frm_main_menu_a174559.Show()
    End Sub

    Private Sub btn_order_details_Click(sender As Object, e As EventArgs) Handles btn_order_list.Click
        frm_orders_a174559.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_order_details.Click
        frm_order_details_a174559.Show()
    End Sub

    Private Sub btn_make_order_Click(sender As Object, e As EventArgs) Handles btn_make_order.Click
        frm_make_order_a174559.Show()
    End Sub

    Private Sub btn_invoice_Click(sender As Object, e As EventArgs) Handles btn_invoice.Click
        frm_view_order_a174559.Show()
    End Sub
End Class