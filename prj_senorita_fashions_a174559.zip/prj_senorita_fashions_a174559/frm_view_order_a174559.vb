﻿Public Class frm_view_order_a174559
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_view_order_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim mysql As String = "SELECT FLD_ODR_ID FROM TBL_ORDER_A174559"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)

        cmb_odr_id.DataSource = mydatatable
        cmb_odr_id.DisplayMember = "FLD_ODR_ID"

        refresh_grid()
        refresh_price()
    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT FLD_PRODUCT_ID, FLD_ODR_QUANTITY, FLD_PRICE_PER_UNIT, FLD_PRICE_PER_UNIT * FLD_ODR_QUANTITY AS SUBTOTAL FROM TBL_ORDER_DETAILS_A174559 WHERE FLD_ODR_ID LIKE ""%" & cmb_odr_id.Text & "%"""

        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)
        grd_inv.DataSource = mydatatable

        grd_inv.Columns(0).HeaderText = "Product ID"
        grd_inv.Columns(1).HeaderText = "Quantity"
        grd_inv.Columns(2).HeaderText = "Price per Unit"
        grd_inv.Columns(3).HeaderText = "Subtotal"

    End Sub

    Private Sub refresh_price()

        If grd_inv.RowCount > 0 Then
            Dim grandtotal As Double
            grandtotal = 0

            For index As Integer = 0 To grd_inv.RowCount - 1
                grandtotal += Convert.ToDouble(grd_inv.Rows(index).Cells(3).Value)
            Next

            txt_grand_totals.Text = "RM " & grandtotal

        ElseIf grd_inv.RowCount = 0 Then

            txt_grand_totals.Text = "RM 0.00"

        End If

    End Sub

    Private Sub cmb_odr_id_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_odr_id.SelectedIndexChanged
        lbl_id.Text = cmb_odr_id.Text
        refresh_grid()
        refresh_price()

    End Sub
End Class