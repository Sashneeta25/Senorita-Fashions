﻿Imports System.ComponentModel

Public Class frm_update_delete_customers_a174559
    Dim current_code As String
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_update_delete_customers_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        refresh_grid()

        get_current_code()
    End Sub

    Private Sub refresh_grid()
        grd_customers.DataSource = run_select("select * from TBL_CUSTOMER_A174559 ORDER BY FLD_CUST_ID ASC")
    End Sub

    Private Sub get_current_code()

        Dim current_row As Integer = grd_customers.CurrentRow.Index

        current_code = grd_customers(0, current_row).Value

        txt_id.Text = current_code
        txt_name.Text = grd_customers(1, current_row).Value
        txt_contact.Text = grd_customers(2, current_row).Value

    End Sub

    Private Sub grd_customers_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd_customers.CellClick
        get_current_code()
    End Sub

    Private Sub txt_name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_name.KeyPress
        If Not Char.IsLetter(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) And Not Char.IsWhiteSpace(e.KeyChar) Then
            btn_update.Enabled = False
            MessageBox.Show("Please enter a valid name. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_name.ClearUndo()
        ElseIf Char.IsLetter(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If txt_name.Text = "" Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_name_Validating(sender As Object, e As CancelEventArgs) Handles txt_name.Validating
        If (txt_name.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub

    Private Sub txt_name_TextChanged(sender As Object, e As EventArgs) Handles txt_name.TextChanged
        If (txt_name.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_contact_Click(sender As Object, e As EventArgs) Handles txt_contact.Click
        If txt_contact.Text = "" Then
            btn_update.Enabled = False
            MessageBox.Show("Please enter a valid phone number of 10 or 11 digits")
        ElseIf txt_contact.Text.Length < 10 Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_contact_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_contact.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) Then
            btn_update.Enabled = False
            MessageBox.Show("Please enter a valid phone number of 10 or 11 digits ONLY. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered a character that is not accepted. Please backspace and enter a valid character again ")
            txt_contact.ClearUndo()
        ElseIf Char.IsNumber(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If txt_contact.Text.Length < 10 Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_contact_Validating(sender As Object, e As CancelEventArgs) Handles txt_contact.Validating
        If txt_contact.Text = "" Then
            btn_update.Enabled = False
        ElseIf Char.IsNumber(txt_contact.Text) Then
            If txt_contact.Text.Length < 10 Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_contact_TextChanged(sender As Object, e As EventArgs) Handles txt_contact.TextChanged
        If txt_contact.Text = "" Then
            btn_update.Enabled = False
        ElseIf Char.IsNumber(txt_contact.Text) Then
            If txt_contact.Text.Length < 10 Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        run_command("update TBL_CUSTOMER_A174559 set FLD_CUST_NAME ='" & txt_name.Text & "', FLD_CONTACT_NUM ='" & txt_contact.Text & "' where FLD_CUST_ID= '" & current_code & "'")

        refresh_grid()
        get_current_code()
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click

        Beep()
        Dim delete_confirmation = MsgBox(" Are you SURE you would like to delete customer  " & current_code & "?", MsgBoxStyle.YesNo)

        If delete_confirmation = MsgBoxResult.Yes Then

            run_command("delete from TBL_CUSTOMER_A174559 where FLD_CUST_ID = '" & current_code & "'")
            Beep()
            MsgBox(" Customer " & current_code & " has been successfully deleted")

            refresh_grid()
            get_current_code()

        End If

    End Sub
End Class