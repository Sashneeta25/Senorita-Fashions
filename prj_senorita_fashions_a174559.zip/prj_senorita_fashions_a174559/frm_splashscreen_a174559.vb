﻿Public Class frm_splashscreen_a174559
    Private Sub btn_explore_Click(sender As Object, e As EventArgs) Handles btn_explore.Click
        frm_main_menu_a174559.Show()
        Me.Hide()
    End Sub

    Private Sub frm_splashscreen_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
