﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_make_order_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_make_order_a174559))
        Me.lbl_insert_new_products = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_order_id = New System.Windows.Forms.TextBox()
        Me.cmb_custid = New System.Windows.Forms.ComboBox()
        Me.cmb_staffid = New System.Windows.Forms.ComboBox()
        Me.lst_product_id = New System.Windows.Forms.ListBox()
        Me.pic_product = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.nup1 = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_grand_totals = New System.Windows.Forms.TextBox()
        Me.btn_close = New System.Windows.Forms.Button()
        Me.btn_add_cart = New System.Windows.Forms.Button()
        Me.grd_cart = New System.Windows.Forms.DataGridView()
        Me.txt_product_name = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_type = New System.Windows.Forms.TextBox()
        Me.btn_remove = New System.Windows.Forms.Button()
        Me.btn_confirm = New System.Windows.Forms.Button()
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nup1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grd_cart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_insert_new_products
        '
        Me.lbl_insert_new_products.AutoSize = True
        Me.lbl_insert_new_products.BackColor = System.Drawing.Color.Yellow
        Me.lbl_insert_new_products.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_insert_new_products.Location = New System.Drawing.Point(452, 9)
        Me.lbl_insert_new_products.Name = "lbl_insert_new_products"
        Me.lbl_insert_new_products.Size = New System.Drawing.Size(288, 35)
        Me.lbl_insert_new_products.TabIndex = 3
        Me.lbl_insert_new_products.Text = "MAKE NEW ORDER"
        Me.lbl_insert_new_products.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Black
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(37, 56)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 29)
        Me.Label2.TabIndex = 62
        Me.Label2.Text = "Order ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Black
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(218, 58)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(157, 29)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Customer ID"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Black
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(462, 58)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(97, 29)
        Me.Label9.TabIndex = 60
        Me.Label9.Text = "Staff ID"
        '
        'txt_order_id
        '
        Me.txt_order_id.Location = New System.Drawing.Point(13, 94)
        Me.txt_order_id.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_order_id.Name = "txt_order_id"
        Me.txt_order_id.ReadOnly = True
        Me.txt_order_id.Size = New System.Drawing.Size(151, 26)
        Me.txt_order_id.TabIndex = 59
        '
        'cmb_custid
        '
        Me.cmb_custid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_custid.FormattingEnabled = True
        Me.cmb_custid.Location = New System.Drawing.Point(224, 92)
        Me.cmb_custid.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmb_custid.Name = "cmb_custid"
        Me.cmb_custid.Size = New System.Drawing.Size(151, 28)
        Me.cmb_custid.TabIndex = 58
        '
        'cmb_staffid
        '
        Me.cmb_staffid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_staffid.FormattingEnabled = True
        Me.cmb_staffid.Location = New System.Drawing.Point(435, 92)
        Me.cmb_staffid.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmb_staffid.Name = "cmb_staffid"
        Me.cmb_staffid.Size = New System.Drawing.Size(151, 28)
        Me.cmb_staffid.TabIndex = 57
        '
        'lst_product_id
        '
        Me.lst_product_id.FormattingEnabled = True
        Me.lst_product_id.ItemHeight = 20
        Me.lst_product_id.Location = New System.Drawing.Point(610, 94)
        Me.lst_product_id.Name = "lst_product_id"
        Me.lst_product_id.Size = New System.Drawing.Size(130, 284)
        Me.lst_product_id.TabIndex = 66
        '
        'pic_product
        '
        Me.pic_product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_product.Location = New System.Drawing.Point(753, 95)
        Me.pic_product.Name = "pic_product"
        Me.pic_product.Size = New System.Drawing.Size(388, 283)
        Me.pic_product.TabIndex = 67
        Me.pic_product.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Black
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(748, 58)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 29)
        Me.Label4.TabIndex = 68
        Me.Label4.Text = "Quantity"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Black
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(604, 58)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(135, 29)
        Me.Label5.TabIndex = 69
        Me.Label5.Text = "Product ID"
        '
        'nup1
        '
        Me.nup1.Location = New System.Drawing.Point(857, 58)
        Me.nup1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.nup1.Name = "nup1"
        Me.nup1.Size = New System.Drawing.Size(53, 26)
        Me.nup1.TabIndex = 70
        Me.nup1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Black
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(918, 58)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 29)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Price"
        '
        'txt_price
        '
        Me.txt_price.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_price.Location = New System.Drawing.Point(1000, 56)
        Me.txt_price.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.ReadOnly = True
        Me.txt_price.Size = New System.Drawing.Size(140, 28)
        Me.txt_price.TabIndex = 71
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(187, 388)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(236, 26)
        Me.Label7.TabIndex = 74
        Me.Label7.Text = "GRAND TOTAL (RM)"
        '
        'txt_grand_totals
        '
        Me.txt_grand_totals.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_grand_totals.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_grand_totals.Location = New System.Drawing.Point(450, 388)
        Me.txt_grand_totals.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_grand_totals.Name = "txt_grand_totals"
        Me.txt_grand_totals.ReadOnly = True
        Me.txt_grand_totals.Size = New System.Drawing.Size(137, 28)
        Me.txt_grand_totals.TabIndex = 73
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Yellow
        Me.btn_close.Font = New System.Drawing.Font("Stencil", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(1002, 516)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(139, 46)
        Me.btn_close.TabIndex = 75
        Me.btn_close.Text = "CLOSE"
        Me.btn_close.UseVisualStyleBackColor = False
        '
        'btn_add_cart
        '
        Me.btn_add_cart.BackColor = System.Drawing.Color.Black
        Me.btn_add_cart.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_add_cart.FlatAppearance.BorderSize = 0
        Me.btn_add_cart.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_add_cart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_add_cart.ForeColor = System.Drawing.Color.White
        Me.btn_add_cart.Location = New System.Drawing.Point(857, 462)
        Me.btn_add_cart.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_add_cart.Name = "btn_add_cart"
        Me.btn_add_cart.Size = New System.Drawing.Size(173, 46)
        Me.btn_add_cart.TabIndex = 77
        Me.btn_add_cart.Text = "Add to Cart"
        Me.btn_add_cart.UseVisualStyleBackColor = False
        '
        'grd_cart
        '
        Me.grd_cart.AllowUserToAddRows = False
        Me.grd_cart.AllowUserToDeleteRows = False
        Me.grd_cart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.grd_cart.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_cart.BackgroundColor = System.Drawing.Color.LightSkyBlue
        Me.grd_cart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_cart.Location = New System.Drawing.Point(12, 130)
        Me.grd_cart.Name = "grd_cart"
        Me.grd_cart.ReadOnly = True
        Me.grd_cart.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.grd_cart.RowTemplate.Height = 28
        Me.grd_cart.Size = New System.Drawing.Size(575, 248)
        Me.grd_cart.TabIndex = 78
        '
        'txt_product_name
        '
        Me.txt_product_name.Location = New System.Drawing.Point(789, 388)
        Me.txt_product_name.Name = "txt_product_name"
        Me.txt_product_name.ReadOnly = True
        Me.txt_product_name.Size = New System.Drawing.Size(351, 26)
        Me.txt_product_name.TabIndex = 79
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Black
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(607, 388)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(179, 29)
        Me.Label8.TabIndex = 80
        Me.Label8.Text = "Product Name"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Black
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(617, 426)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(169, 29)
        Me.Label10.TabIndex = 82
        Me.Label10.Text = "Product Type"
        '
        'txt_type
        '
        Me.txt_type.Location = New System.Drawing.Point(790, 426)
        Me.txt_type.Name = "txt_type"
        Me.txt_type.ReadOnly = True
        Me.txt_type.Size = New System.Drawing.Size(351, 26)
        Me.txt_type.TabIndex = 81
        '
        'btn_remove
        '
        Me.btn_remove.BackColor = System.Drawing.Color.Red
        Me.btn_remove.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_remove.FlatAppearance.BorderSize = 0
        Me.btn_remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_remove.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_remove.ForeColor = System.Drawing.Color.White
        Me.btn_remove.Location = New System.Drawing.Point(12, 381)
        Me.btn_remove.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_remove.Name = "btn_remove"
        Me.btn_remove.Size = New System.Drawing.Size(167, 36)
        Me.btn_remove.TabIndex = 84
        Me.btn_remove.Text = "Remove Item"
        Me.btn_remove.UseVisualStyleBackColor = False
        '
        'btn_confirm
        '
        Me.btn_confirm.BackColor = System.Drawing.Color.Lime
        Me.btn_confirm.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_confirm.FlatAppearance.BorderSize = 0
        Me.btn_confirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_confirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_confirm.ForeColor = System.Drawing.Color.Black
        Me.btn_confirm.Location = New System.Drawing.Point(477, 514)
        Me.btn_confirm.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_confirm.Name = "btn_confirm"
        Me.btn_confirm.Size = New System.Drawing.Size(198, 46)
        Me.btn_confirm.TabIndex = 83
        Me.btn_confirm.Text = "Confirm Order"
        Me.btn_confirm.UseVisualStyleBackColor = False
        '
        'frm_make_order_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1153, 574)
        Me.Controls.Add(Me.btn_remove)
        Me.Controls.Add(Me.btn_confirm)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txt_type)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_product_name)
        Me.Controls.Add(Me.grd_cart)
        Me.Controls.Add(Me.btn_add_cart)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt_grand_totals)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.nup1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.pic_product)
        Me.Controls.Add(Me.lst_product_id)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txt_order_id)
        Me.Controls.Add(Me.cmb_custid)
        Me.Controls.Add(Me.cmb_staffid)
        Me.Controls.Add(Me.lbl_insert_new_products)
        Me.MaximizeBox = False
        Me.Name = "frm_make_order_a174559"
        Me.Text = "SENORITA FASHIONS- MAKE ORDER"
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nup1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grd_cart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_insert_new_products As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_order_id As TextBox
    Friend WithEvents cmb_custid As ComboBox
    Friend WithEvents cmb_staffid As ComboBox
    Friend WithEvents lst_product_id As ListBox
    Friend WithEvents pic_product As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents nup1 As NumericUpDown
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_price As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_grand_totals As TextBox
    Friend WithEvents btn_close As Button
    Friend WithEvents btn_add_cart As Button
    Friend WithEvents grd_cart As DataGridView
    Friend WithEvents txt_product_name As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_type As TextBox
    Friend WithEvents btn_remove As Button
    Friend WithEvents btn_confirm As Button
End Class
