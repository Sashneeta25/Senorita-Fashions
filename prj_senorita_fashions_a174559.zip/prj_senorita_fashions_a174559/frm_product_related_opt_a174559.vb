﻿Public Class frm_product_related_opt_a174559
    Private Sub Product_related_opt_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        Me.Close()
        frm_main_menu_a174559.Show()
    End Sub

    Private Sub btn_product_details_Click(sender As Object, e As EventArgs) Handles btn_product_details.Click
        frm_product_details_a174559.Show()
    End Sub

    Private Sub btn_insert_products_Click(sender As Object, e As EventArgs) Handles btn_insert_products.Click
        frm_insert_products_a174559.Show()
    End Sub

    Private Sub btn_update_delete_products_Click(sender As Object, e As EventArgs) Handles btn_update_delete_products.Click
        frm_update_delete_products_a174559.Show()
    End Sub

    Private Sub btn_products_Click(sender As Object, e As EventArgs) Handles btn_products.Click
        frm_products_a174559.Show()
    End Sub
End Class