﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_customers_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_customers_a174559))
        Me.btn_close = New System.Windows.Forms.Button()
        Me.lbl_customers = New System.Windows.Forms.Label()
        Me.grd_customers = New System.Windows.Forms.DataGridView()
        CType(Me.grd_customers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Yellow
        Me.btn_close.Font = New System.Drawing.Font("Stencil", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(1002, 516)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(139, 46)
        Me.btn_close.TabIndex = 0
        Me.btn_close.Text = "CLOSE"
        Me.btn_close.UseVisualStyleBackColor = False
        '
        'lbl_customers
        '
        Me.lbl_customers.AutoSize = True
        Me.lbl_customers.BackColor = System.Drawing.Color.Yellow
        Me.lbl_customers.Font = New System.Drawing.Font("Stencil", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_customers.Location = New System.Drawing.Point(470, 9)
        Me.lbl_customers.Name = "lbl_customers"
        Me.lbl_customers.Size = New System.Drawing.Size(231, 43)
        Me.lbl_customers.TabIndex = 1
        Me.lbl_customers.Text = "CUSTOMERS"
        '
        'grd_customers
        '
        Me.grd_customers.AllowUserToAddRows = False
        Me.grd_customers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_customers.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_customers.BackgroundColor = System.Drawing.Color.PowderBlue
        Me.grd_customers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_customers.Location = New System.Drawing.Point(24, 70)
        Me.grd_customers.Name = "grd_customers"
        Me.grd_customers.ReadOnly = True
        Me.grd_customers.RowHeadersWidth = 62
        Me.grd_customers.RowTemplate.Height = 28
        Me.grd_customers.Size = New System.Drawing.Size(1103, 440)
        Me.grd_customers.TabIndex = 2
        '
        'frm_customers_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1153, 574)
        Me.Controls.Add(Me.grd_customers)
        Me.Controls.Add(Me.lbl_customers)
        Me.Controls.Add(Me.btn_close)
        Me.MaximizeBox = False
        Me.Name = "frm_customers_a174559"
        Me.Text = "SENORITA FASHIONS-CUSTOMERS"
        CType(Me.grd_customers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_close As Button
    Friend WithEvents lbl_customers As Label
    Friend WithEvents grd_customers As DataGridView
End Class
