﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_splashscreen_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_splashscreen_a174559))
        Me.lbl_title_1 = New System.Windows.Forms.Label()
        Me.lbl_title_2 = New System.Windows.Forms.Label()
        Me.lbl_caption_1 = New System.Windows.Forms.Label()
        Me.lbl_caption_2 = New System.Windows.Forms.Label()
        Me.lbl_caption_3 = New System.Windows.Forms.Label()
        Me.btn_explore = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbl_title_1
        '
        Me.lbl_title_1.AutoSize = True
        Me.lbl_title_1.BackColor = System.Drawing.Color.GreenYellow
        Me.lbl_title_1.Font = New System.Drawing.Font("Broadway", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title_1.Location = New System.Drawing.Point(592, 22)
        Me.lbl_title_1.Name = "lbl_title_1"
        Me.lbl_title_1.Size = New System.Drawing.Size(337, 63)
        Me.lbl_title_1.TabIndex = 0
        Me.lbl_title_1.Text = "SENORITA"
        '
        'lbl_title_2
        '
        Me.lbl_title_2.AutoSize = True
        Me.lbl_title_2.BackColor = System.Drawing.Color.GreenYellow
        Me.lbl_title_2.Font = New System.Drawing.Font("Broadway", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title_2.Location = New System.Drawing.Point(794, 95)
        Me.lbl_title_2.Name = "lbl_title_2"
        Me.lbl_title_2.Size = New System.Drawing.Size(330, 63)
        Me.lbl_title_2.TabIndex = 1
        Me.lbl_title_2.Text = "FASHIONS"
        '
        'lbl_caption_1
        '
        Me.lbl_caption_1.AutoSize = True
        Me.lbl_caption_1.BackColor = System.Drawing.Color.Cyan
        Me.lbl_caption_1.Font = New System.Drawing.Font("Broadway", 22.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_caption_1.Location = New System.Drawing.Point(770, 225)
        Me.lbl_caption_1.Name = "lbl_caption_1"
        Me.lbl_caption_1.Size = New System.Drawing.Size(357, 50)
        Me.lbl_caption_1.TabIndex = 2
        Me.lbl_caption_1.Text = "The Best Look"
        '
        'lbl_caption_2
        '
        Me.lbl_caption_2.AutoSize = True
        Me.lbl_caption_2.BackColor = System.Drawing.Color.Cyan
        Me.lbl_caption_2.Font = New System.Drawing.Font("Broadway", 22.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_caption_2.Location = New System.Drawing.Point(831, 298)
        Me.lbl_caption_2.Name = "lbl_caption_2"
        Me.lbl_caption_2.Size = New System.Drawing.Size(235, 50)
        Me.lbl_caption_2.TabIndex = 3
        Me.lbl_caption_2.Text = "Anytime"
        '
        'lbl_caption_3
        '
        Me.lbl_caption_3.AutoSize = True
        Me.lbl_caption_3.BackColor = System.Drawing.Color.Cyan
        Me.lbl_caption_3.Font = New System.Drawing.Font("Broadway", 22.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_caption_3.Location = New System.Drawing.Point(809, 371)
        Me.lbl_caption_3.Name = "lbl_caption_3"
        Me.lbl_caption_3.Size = New System.Drawing.Size(288, 50)
        Me.lbl_caption_3.TabIndex = 4
        Me.lbl_caption_3.Text = "Anywhere!"
        '
        'btn_explore
        '
        Me.btn_explore.BackColor = System.Drawing.Color.DeepPink
        Me.btn_explore.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn_explore.Font = New System.Drawing.Font("Broadway", 22.0!, System.Drawing.FontStyle.Bold)
        Me.btn_explore.ForeColor = System.Drawing.Color.Black
        Me.btn_explore.Location = New System.Drawing.Point(805, 479)
        Me.btn_explore.Name = "btn_explore"
        Me.btn_explore.Size = New System.Drawing.Size(319, 68)
        Me.btn_explore.TabIndex = 5
        Me.btn_explore.Text = "Explore"
        Me.btn_explore.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Fuchsia
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(12, 497)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(349, 32)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "SASHNEETA SUBAHAR"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Fuchsia
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(12, 533)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 32)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "A174559"
        '
        'frm_splashscreen_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1153, 574)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_explore)
        Me.Controls.Add(Me.lbl_caption_3)
        Me.Controls.Add(Me.lbl_caption_2)
        Me.Controls.Add(Me.lbl_caption_1)
        Me.Controls.Add(Me.lbl_title_2)
        Me.Controls.Add(Me.lbl_title_1)
        Me.MaximizeBox = False
        Me.Name = "frm_splashscreen_a174559"
        Me.Text = "WELCOME TO SENORITA FASHIONS "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title_1 As Label
    Friend WithEvents lbl_title_2 As Label
    Friend WithEvents lbl_caption_1 As Label
    Friend WithEvents lbl_caption_2 As Label
    Friend WithEvents lbl_caption_3 As Label
    Friend WithEvents btn_explore As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
