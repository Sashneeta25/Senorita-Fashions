﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_cust_related_opt_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_cust_related_opt_a174559))
        Me.btn_customers_list = New System.Windows.Forms.Button()
        Me.btn_insert_customers = New System.Windows.Forms.Button()
        Me.btn_update_delete_customers = New System.Windows.Forms.Button()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_customers_list
        '
        Me.btn_customers_list.BackColor = System.Drawing.Color.MediumOrchid
        Me.btn_customers_list.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customers_list.Location = New System.Drawing.Point(12, 12)
        Me.btn_customers_list.Name = "btn_customers_list"
        Me.btn_customers_list.Size = New System.Drawing.Size(345, 53)
        Me.btn_customers_list.TabIndex = 5
        Me.btn_customers_list.Text = "Customers List"
        Me.btn_customers_list.UseVisualStyleBackColor = False
        '
        'btn_insert_customers
        '
        Me.btn_insert_customers.BackColor = System.Drawing.Color.MediumOrchid
        Me.btn_insert_customers.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insert_customers.Location = New System.Drawing.Point(12, 85)
        Me.btn_insert_customers.Name = "btn_insert_customers"
        Me.btn_insert_customers.Size = New System.Drawing.Size(345, 53)
        Me.btn_insert_customers.TabIndex = 14
        Me.btn_insert_customers.Text = "Insert New Customers"
        Me.btn_insert_customers.UseVisualStyleBackColor = False
        '
        'btn_update_delete_customers
        '
        Me.btn_update_delete_customers.BackColor = System.Drawing.Color.MediumOrchid
        Me.btn_update_delete_customers.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update_delete_customers.ForeColor = System.Drawing.Color.Black
        Me.btn_update_delete_customers.Location = New System.Drawing.Point(12, 158)
        Me.btn_update_delete_customers.Name = "btn_update_delete_customers"
        Me.btn_update_delete_customers.Size = New System.Drawing.Size(345, 53)
        Me.btn_update_delete_customers.TabIndex = 15
        Me.btn_update_delete_customers.Text = "Update/Delete Customers"
        Me.btn_update_delete_customers.UseVisualStyleBackColor = False
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.Yellow
        Me.btn_back.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(821, 487)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(145, 45)
        Me.btn_back.TabIndex = 16
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_cust_related_opt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(978, 544)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_update_delete_customers)
        Me.Controls.Add(Me.btn_insert_customers)
        Me.Controls.Add(Me.btn_customers_list)
        Me.MaximizeBox = False
        Me.Name = "frm_cust_related_opt"
        Me.Text = "SENORITA FASHIONS- RELATED OPTIONS (CUSTOMERS)"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_customers_list As Button
    Friend WithEvents btn_insert_customers As Button
    Friend WithEvents btn_update_delete_customers As Button
    Friend WithEvents btn_back As Button
End Class
