﻿Imports System.ComponentModel

Public Class frm_insert_products_a174559

    Dim defaultpicture As String = Application.StartupPath & "\pictures\NoImage.jpg"

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_insert_products_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmb_material.DataSource = run_select("select FLD_MATERIAL from TBL_PRODUCTS_A174559 GROUP BY FLD_MATERIAL")
        cmb_material.DisplayMember = "FLD_MATERIAL"
        cmb_style.DataSource = run_select("select FLD_STYLE from TBL_PRODUCTS_A174559 GROUP BY FLD_STYLE")
        cmb_style.DisplayMember = "FLD_STYLE"
        cmb_ships_from.DataSource = run_select("select FLD_SHIPS_FROM from TBL_PRODUCTS_A174559 GROUP BY FLD_SHIPS_FROM")
        cmb_ships_from.DisplayMember = "FLD_SHIPS_FROM"
        cmb_type.DataSource = run_select("select FLD_TYPE from TBL_PRODUCTS_A174559 GROUP BY FLD_TYPE")
        cmb_type.DisplayMember = "FLD_TYPE"
        refresh_grid()

    End Sub
    Private Sub refresh_grid()

        grd_products.DataSource = run_select("select * from TBL_PRODUCTS_A174559")

        txt_id.Text = generate_id()

        txt_name.Text = ""
        txt_price.Text = ""
        txt_quantity.Text = ""
        cmb_material.DataSource = run_select("select FLD_MATERIAL from TBL_PRODUCTS_A174559 GROUP BY FLD_MATERIAL")
        cmb_material.DisplayMember = "FLD_MATERIAL"
        cmb_style.DataSource = run_select("select FLD_STYLE from TBL_PRODUCTS_A174559 GROUP BY FLD_STYLE")
        cmb_style.DisplayMember = "FLD_STYLE"
        cmb_ships_from.DataSource = run_select("select FLD_SHIPS_FROM from TBL_PRODUCTS_A174559 GROUP BY FLD_SHIPS_FROM")
        cmb_ships_from.DisplayMember = "FLD_SHIPS_FROM"
        cmb_type.DataSource = run_select("select FLD_TYPE from TBL_PRODUCTS_A174559 GROUP BY FLD_TYPE")
        cmb_type.DisplayMember = "FLD_TYPE"
        txt_pic_path.Text = defaultpicture
        product_pic.BackgroundImage = Image.FromFile(defaultpicture)

        If txt_name.Text = "" And txt_price.Text = "" And txt_quantity.Text = "" Then
            btn_insert.Enabled = False
        End If

    End Sub
    Private Function generate_id() As String

        Dim lastid As String = run_select("select max(FLD_PRODUCT_ID) as maxID from TBL_PRODUCTS_A174559").Rows(0).Item("maxID")

        'MsgBox(lastmatric)

        Dim newid As String = "P" & Mid(lastid, 2) + 1

        Return newid

    End Function
    Private Sub txt_name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_name.KeyPress
        If Not Char.IsLetter(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) And Not Char.IsWhiteSpace(e.KeyChar) Then
            btn_insert.Enabled = False
            MessageBox.Show("Please enter a valid product name. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_name.ClearUndo()
        ElseIf Char.IsLetter(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If txt_name.Text = "" Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_name_Validating(sender As Object, e As CancelEventArgs) Handles txt_name.Validating
        If (txt_name.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_name_TextChanged(sender As Object, e As EventArgs) Handles txt_name.TextChanged
        If (txt_name.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_price_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_price.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) And Not Char.IsPunctuation(e.KeyChar) Then
            btn_insert.Enabled = False
            MessageBox.Show("Please enter a valid price value of digits ONLY. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_price.ClearUndo()
        ElseIf Char.IsDigit(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If (txt_price.Text = "") Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_price_Validating(sender As Object, e As CancelEventArgs) Handles txt_price.Validating
        If (txt_price.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_price_TextChanged(sender As Object, e As EventArgs) Handles txt_price.TextChanged
        If (txt_price.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_quantity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_quantity.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) Then
            btn_insert.Enabled = False
            MessageBox.Show("Please enter a valid quantity of digits ONLY. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_price.ClearUndo()
        ElseIf Char.IsNumber(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If (txt_quantity.Text = "") Then
                btn_insert.Enabled = False
            Else
                btn_insert.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_quantity_TextChanged(sender As Object, e As EventArgs) Handles txt_quantity.TextChanged
        If (txt_quantity.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub txt_quantity_Validating(sender As Object, e As CancelEventArgs) Handles txt_quantity.Validating
        If (txt_quantity.Text = "") Then
            btn_insert.Enabled = False
        Else
            btn_insert.Enabled = True
        End If
    End Sub
    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click

        Dim mysql As String = "insert into TBL_PRODUCTS_A174559 values ('" & txt_id.Text & "', '" & txt_name.Text & "', " & txt_price.Text & ", '" & cmb_material.Text & "', '" & cmb_style.Text & "','" & cmb_ships_from.Text & "', " & txt_quantity.Text & ",'" & cmb_type.Text & "')"
        'MsgBox(mysql)
        Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2)

        Try

            mywriter.Connection.Open()
            mywriter.ExecuteNonQuery()
            mywriter.Connection.Close()

            My.Computer.FileSystem.CopyFile(txt_pic_path.Text, "pictures\" & txt_id.Text & ".jpg")

            refresh_grid()

        Catch ex As Exception

            Beep()
            MsgBox("There is a Mistake in the data that you entered as shown below: " & vbCrLf & vbCrLf & ex.Message)
            mywriter.Connection.Close()
        End Try
    End Sub
    Private Sub btn_pic_Click(sender As Object, e As EventArgs) Handles btn_pic.Click

        Dim mypictures As String = My.Computer.FileSystem.SpecialDirectories.MyPictures
        Try
            OpenFileDialog1.InitialDirectory = mypictures
            OpenFileDialog1.FileName = ""
            OpenFileDialog1.ShowDialog()
            txt_pic_path.Text = OpenFileDialog1.FileName
            product_pic.BackgroundImage = Image.FromFile(OpenFileDialog1.FileName)

        Catch ex As Exception
            txt_pic_path.Text = defaultpicture
            product_pic.BackgroundImage = Image.FromFile(defaultpicture)
        End Try

    End Sub
End Class