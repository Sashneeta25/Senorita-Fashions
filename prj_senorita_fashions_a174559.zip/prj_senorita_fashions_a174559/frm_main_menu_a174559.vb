﻿Public Class frm_main_menu_a174559
    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        End
    End Sub

    Private Sub frm_main_menu_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim current_date As String = Date.Now
        'MsgBox(current_date)
        lbl_date.Text = current_date
    End Sub

    Private Sub btn_products_Click(sender As Object, e As EventArgs) Handles btn_products.Click
        frm_product_related_opt_a174559.Show()
    End Sub

    Private Sub btn_customers_Click(sender As Object, e As EventArgs) Handles btn_customers.Click
        frm_cust_related_opt_a174559.Show()
    End Sub

    Private Sub btn_orders_Click(sender As Object, e As EventArgs) Handles btn_orders.Click
        frm_odr_related_opt_a174559.Show()
    End Sub

    Private Sub btn_staffs_Click(sender As Object, e As EventArgs) Handles btn_staffs.Click
        frm_staff_related_opt_a174559.Show()
    End Sub

    Private Sub btn_insert_staffs_Click(sender As Object, e As EventArgs)
        frm_insert_staffs_a174559.Show()
    End Sub

    Private Sub btn_insert_customers_Click(sender As Object, e As EventArgs)
        frm_insert_customers_a174559.Show()
    End Sub

    Private Sub btn_update_delete_staffs_Click(sender As Object, e As EventArgs)
        frm_update_delete_staffs_a174559.Show()
    End Sub

    Private Sub btn_update_delete_customers_Click(sender As Object, e As EventArgs)
        frm_update_delete_customers_a174559.Show()
    End Sub

End Class