﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_product_details_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_product_details_a174559))
        Me.lbl_product_id = New System.Windows.Forms.Label()
        Me.pic_product = New System.Windows.Forms.PictureBox()
        Me.btn_close = New System.Windows.Forms.Button()
        Me.lbl_product_details = New System.Windows.Forms.Label()
        Me.lst_product_id = New System.Windows.Forms.ListBox()
        Me.lbl_product_name = New System.Windows.Forms.Label()
        Me.txt_product_name = New System.Windows.Forms.TextBox()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.lbl_price = New System.Windows.Forms.Label()
        Me.txt_material = New System.Windows.Forms.TextBox()
        Me.lbl_material = New System.Windows.Forms.Label()
        Me.txt_style = New System.Windows.Forms.TextBox()
        Me.lbl_style = New System.Windows.Forms.Label()
        Me.txt_ships_from = New System.Windows.Forms.TextBox()
        Me.lbl_ships_from = New System.Windows.Forms.Label()
        Me.txt_quantity = New System.Windows.Forms.TextBox()
        Me.lbl_quantity = New System.Windows.Forms.Label()
        Me.txt_type = New System.Windows.Forms.TextBox()
        Me.lbl_type = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_product_id
        '
        Me.lbl_product_id.AutoSize = True
        Me.lbl_product_id.BackColor = System.Drawing.Color.Yellow
        Me.lbl_product_id.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_product_id.Location = New System.Drawing.Point(56, 96)
        Me.lbl_product_id.Name = "lbl_product_id"
        Me.lbl_product_id.Size = New System.Drawing.Size(152, 29)
        Me.lbl_product_id.TabIndex = 0
        Me.lbl_product_id.Text = "Product ID"
        '
        'pic_product
        '
        Me.pic_product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_product.Location = New System.Drawing.Point(276, 128)
        Me.pic_product.Name = "pic_product"
        Me.pic_product.Size = New System.Drawing.Size(523, 363)
        Me.pic_product.TabIndex = 1
        Me.pic_product.TabStop = False
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Yellow
        Me.btn_close.Font = New System.Drawing.Font("Stencil", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(1002, 516)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(139, 46)
        Me.btn_close.TabIndex = 2
        Me.btn_close.Text = "CLOSE"
        Me.btn_close.UseVisualStyleBackColor = False
        '
        'lbl_product_details
        '
        Me.lbl_product_details.AutoSize = True
        Me.lbl_product_details.BackColor = System.Drawing.Color.Yellow
        Me.lbl_product_details.Font = New System.Drawing.Font("Stencil", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_product_details.Location = New System.Drawing.Point(387, 9)
        Me.lbl_product_details.Name = "lbl_product_details"
        Me.lbl_product_details.Size = New System.Drawing.Size(337, 38)
        Me.lbl_product_details.TabIndex = 3
        Me.lbl_product_details.Text = "PRODUCTs CATALOG"
        '
        'lst_product_id
        '
        Me.lst_product_id.FormattingEnabled = True
        Me.lst_product_id.ItemHeight = 20
        Me.lst_product_id.Location = New System.Drawing.Point(12, 128)
        Me.lst_product_id.Name = "lst_product_id"
        Me.lst_product_id.Size = New System.Drawing.Size(241, 424)
        Me.lst_product_id.TabIndex = 4
        '
        'lbl_product_name
        '
        Me.lbl_product_name.AutoSize = True
        Me.lbl_product_name.BackColor = System.Drawing.Color.Yellow
        Me.lbl_product_name.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_product_name.Location = New System.Drawing.Point(444, 494)
        Me.lbl_product_name.Name = "lbl_product_name"
        Me.lbl_product_name.Size = New System.Drawing.Size(190, 29)
        Me.lbl_product_name.TabIndex = 5
        Me.lbl_product_name.Text = "Product Name"
        '
        'txt_product_name
        '
        Me.txt_product_name.Location = New System.Drawing.Point(267, 527)
        Me.txt_product_name.Name = "txt_product_name"
        Me.txt_product_name.ReadOnly = True
        Me.txt_product_name.Size = New System.Drawing.Size(532, 26)
        Me.txt_product_name.TabIndex = 6
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(824, 143)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.ReadOnly = True
        Me.txt_price.Size = New System.Drawing.Size(307, 26)
        Me.txt_price.TabIndex = 8
        '
        'lbl_price
        '
        Me.lbl_price.AutoSize = True
        Me.lbl_price.BackColor = System.Drawing.Color.Yellow
        Me.lbl_price.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_price.Location = New System.Drawing.Point(936, 109)
        Me.lbl_price.Name = "lbl_price"
        Me.lbl_price.Size = New System.Drawing.Size(83, 29)
        Me.lbl_price.TabIndex = 7
        Me.lbl_price.Text = "Price"
        '
        'txt_material
        '
        Me.txt_material.Location = New System.Drawing.Point(824, 208)
        Me.txt_material.Name = "txt_material"
        Me.txt_material.ReadOnly = True
        Me.txt_material.Size = New System.Drawing.Size(307, 26)
        Me.txt_material.TabIndex = 10
        '
        'lbl_material
        '
        Me.lbl_material.AutoSize = True
        Me.lbl_material.BackColor = System.Drawing.Color.Yellow
        Me.lbl_material.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_material.Location = New System.Drawing.Point(912, 174)
        Me.lbl_material.Name = "lbl_material"
        Me.lbl_material.Size = New System.Drawing.Size(130, 29)
        Me.lbl_material.TabIndex = 9
        Me.lbl_material.Text = "Material"
        '
        'txt_style
        '
        Me.txt_style.Location = New System.Drawing.Point(824, 273)
        Me.txt_style.Name = "txt_style"
        Me.txt_style.ReadOnly = True
        Me.txt_style.Size = New System.Drawing.Size(307, 26)
        Me.txt_style.TabIndex = 12
        '
        'lbl_style
        '
        Me.lbl_style.AutoSize = True
        Me.lbl_style.BackColor = System.Drawing.Color.Yellow
        Me.lbl_style.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_style.Location = New System.Drawing.Point(937, 239)
        Me.lbl_style.Name = "lbl_style"
        Me.lbl_style.Size = New System.Drawing.Size(81, 29)
        Me.lbl_style.TabIndex = 11
        Me.lbl_style.Text = "Style"
        '
        'txt_ships_from
        '
        Me.txt_ships_from.Location = New System.Drawing.Point(824, 338)
        Me.txt_ships_from.Name = "txt_ships_from"
        Me.txt_ships_from.ReadOnly = True
        Me.txt_ships_from.Size = New System.Drawing.Size(307, 26)
        Me.txt_ships_from.TabIndex = 14
        '
        'lbl_ships_from
        '
        Me.lbl_ships_from.AutoSize = True
        Me.lbl_ships_from.BackColor = System.Drawing.Color.Yellow
        Me.lbl_ships_from.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ships_from.Location = New System.Drawing.Point(901, 304)
        Me.lbl_ships_from.Name = "lbl_ships_from"
        Me.lbl_ships_from.Size = New System.Drawing.Size(153, 29)
        Me.lbl_ships_from.TabIndex = 13
        Me.lbl_ships_from.Text = "Ships From"
        '
        'txt_quantity
        '
        Me.txt_quantity.Location = New System.Drawing.Point(824, 403)
        Me.txt_quantity.Name = "txt_quantity"
        Me.txt_quantity.ReadOnly = True
        Me.txt_quantity.Size = New System.Drawing.Size(307, 26)
        Me.txt_quantity.TabIndex = 16
        '
        'lbl_quantity
        '
        Me.lbl_quantity.AutoSize = True
        Me.lbl_quantity.BackColor = System.Drawing.Color.Yellow
        Me.lbl_quantity.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_quantity.Location = New System.Drawing.Point(914, 369)
        Me.lbl_quantity.Name = "lbl_quantity"
        Me.lbl_quantity.Size = New System.Drawing.Size(127, 29)
        Me.lbl_quantity.TabIndex = 15
        Me.lbl_quantity.Text = "Quantity"
        '
        'txt_type
        '
        Me.txt_type.Location = New System.Drawing.Point(824, 468)
        Me.txt_type.Name = "txt_type"
        Me.txt_type.ReadOnly = True
        Me.txt_type.Size = New System.Drawing.Size(307, 26)
        Me.txt_type.TabIndex = 18
        '
        'lbl_type
        '
        Me.lbl_type.AutoSize = True
        Me.lbl_type.BackColor = System.Drawing.Color.Yellow
        Me.lbl_type.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_type.Location = New System.Drawing.Point(942, 434)
        Me.lbl_type.Name = "lbl_type"
        Me.lbl_type.Size = New System.Drawing.Size(70, 29)
        Me.lbl_type.TabIndex = 17
        Me.lbl_type.Text = "Type"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Chartreuse
        Me.Label1.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(44, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1080, 29)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Click on any procuct id below or use key up and down to navigate through the list" &
    ""
        '
        'frm_product_details_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1153, 574)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_type)
        Me.Controls.Add(Me.lbl_type)
        Me.Controls.Add(Me.txt_quantity)
        Me.Controls.Add(Me.lbl_quantity)
        Me.Controls.Add(Me.txt_ships_from)
        Me.Controls.Add(Me.lbl_ships_from)
        Me.Controls.Add(Me.txt_style)
        Me.Controls.Add(Me.lbl_style)
        Me.Controls.Add(Me.txt_material)
        Me.Controls.Add(Me.lbl_material)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.lbl_price)
        Me.Controls.Add(Me.txt_product_name)
        Me.Controls.Add(Me.lbl_product_name)
        Me.Controls.Add(Me.lst_product_id)
        Me.Controls.Add(Me.lbl_product_details)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.pic_product)
        Me.Controls.Add(Me.lbl_product_id)
        Me.MaximizeBox = False
        Me.Name = "frm_product_details_a174559"
        Me.Text = "SENORITA FASHIONS-PRODUCT DETAILS"
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_product_id As Label
    Friend WithEvents pic_product As PictureBox
    Friend WithEvents btn_close As Button
    Friend WithEvents lbl_product_details As Label
    Friend WithEvents lst_product_id As ListBox
    Friend WithEvents lbl_product_name As Label
    Friend WithEvents txt_product_name As TextBox
    Friend WithEvents txt_price As TextBox
    Friend WithEvents lbl_price As Label
    Friend WithEvents txt_material As TextBox
    Friend WithEvents lbl_material As Label
    Friend WithEvents txt_style As TextBox
    Friend WithEvents lbl_style As Label
    Friend WithEvents txt_ships_from As TextBox
    Friend WithEvents lbl_ships_from As Label
    Friend WithEvents txt_quantity As TextBox
    Friend WithEvents lbl_quantity As Label
    Friend WithEvents txt_type As TextBox
    Friend WithEvents lbl_type As Label
    Friend WithEvents Label1 As Label
End Class
