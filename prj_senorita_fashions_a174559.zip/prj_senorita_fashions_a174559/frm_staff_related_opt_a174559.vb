﻿Public Class frm_staff_related_opt_a174559
    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        Me.Close()
        frm_main_menu_a174559.Show()
    End Sub

    Private Sub btn_staffs_Click(sender As Object, e As EventArgs) Handles btn_staffs.Click
        frm_staffs_a174559.Show()
    End Sub

    Private Sub btn_insert_staffs_Click(sender As Object, e As EventArgs) Handles btn_insert_staffs.Click
        frm_insert_staffs_a174559.Show()
    End Sub

    Private Sub btn_update_delete_staffs_Click(sender As Object, e As EventArgs) Handles btn_update_delete_staffs.Click
        frm_update_delete_staffs_a174559.Show()
    End Sub
End Class