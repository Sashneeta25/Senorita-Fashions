﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_insert_products_a174559
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_insert_products_a174559))
        Me.btn_close = New System.Windows.Forms.Button()
        Me.lbl_insert_new_products = New System.Windows.Forms.Label()
        Me.grd_products = New System.Windows.Forms.DataGridView()
        Me.lbl_instruction = New System.Windows.Forms.Label()
        Me.btn_insert = New System.Windows.Forms.Button()
        Me.product_pic = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_pic_path = New System.Windows.Forms.TextBox()
        Me.btn_pic = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_quantity = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmb_type = New System.Windows.Forms.ComboBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.cmb_material = New System.Windows.Forms.ComboBox()
        Me.cmb_style = New System.Windows.Forms.ComboBox()
        Me.cmb_ships_from = New System.Windows.Forms.ComboBox()
        CType(Me.grd_products, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.product_pic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Yellow
        Me.btn_close.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(1004, 520)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(137, 42)
        Me.btn_close.TabIndex = 1
        Me.btn_close.Text = "CLOSE"
        Me.btn_close.UseVisualStyleBackColor = False
        '
        'lbl_insert_new_products
        '
        Me.lbl_insert_new_products.AutoSize = True
        Me.lbl_insert_new_products.BackColor = System.Drawing.Color.Yellow
        Me.lbl_insert_new_products.Font = New System.Drawing.Font("Stencil", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_insert_new_products.Location = New System.Drawing.Point(394, 9)
        Me.lbl_insert_new_products.Name = "lbl_insert_new_products"
        Me.lbl_insert_new_products.Size = New System.Drawing.Size(370, 35)
        Me.lbl_insert_new_products.TabIndex = 2
        Me.lbl_insert_new_products.Text = "INSERT NEW PRODUCTS"
        '
        'grd_products
        '
        Me.grd_products.AllowUserToAddRows = False
        Me.grd_products.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_products.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_products.BackgroundColor = System.Drawing.Color.Plum
        Me.grd_products.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_products.Location = New System.Drawing.Point(12, 47)
        Me.grd_products.Name = "grd_products"
        Me.grd_products.ReadOnly = True
        Me.grd_products.RowHeadersWidth = 62
        Me.grd_products.RowTemplate.Height = 28
        Me.grd_products.Size = New System.Drawing.Size(1129, 283)
        Me.grd_products.TabIndex = 3
        '
        'lbl_instruction
        '
        Me.lbl_instruction.AutoSize = True
        Me.lbl_instruction.BackColor = System.Drawing.Color.Gold
        Me.lbl_instruction.Font = New System.Drawing.Font("Times New Roman", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_instruction.Location = New System.Drawing.Point(12, 333)
        Me.lbl_instruction.Name = "lbl_instruction"
        Me.lbl_instruction.Size = New System.Drawing.Size(387, 25)
        Me.lbl_instruction.TabIndex = 4
        Me.lbl_instruction.Text = "Please enter new product's details below:"
        '
        'btn_insert
        '
        Me.btn_insert.BackColor = System.Drawing.Color.Gold
        Me.btn_insert.Font = New System.Drawing.Font("Bookman Old Style", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insert.ForeColor = System.Drawing.Color.Black
        Me.btn_insert.Location = New System.Drawing.Point(460, 520)
        Me.btn_insert.Name = "btn_insert"
        Me.btn_insert.Size = New System.Drawing.Size(256, 45)
        Me.btn_insert.TabIndex = 5
        Me.btn_insert.Text = "Insert New Product"
        Me.btn_insert.UseVisualStyleBackColor = False
        '
        'product_pic
        '
        Me.product_pic.BackColor = System.Drawing.Color.White
        Me.product_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.product_pic.Location = New System.Drawing.Point(12, 364)
        Me.product_pic.Name = "product_pic"
        Me.product_pic.Size = New System.Drawing.Size(184, 198)
        Me.product_pic.TabIndex = 6
        Me.product_pic.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Khaki
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(202, 370)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(183, 20)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Product's Photo Path:"
        '
        'txt_pic_path
        '
        Me.txt_pic_path.BackColor = System.Drawing.Color.White
        Me.txt_pic_path.Location = New System.Drawing.Point(400, 364)
        Me.txt_pic_path.Name = "txt_pic_path"
        Me.txt_pic_path.ReadOnly = True
        Me.txt_pic_path.Size = New System.Drawing.Size(389, 26)
        Me.txt_pic_path.TabIndex = 8
        '
        'btn_pic
        '
        Me.btn_pic.BackColor = System.Drawing.Color.LightSalmon
        Me.btn_pic.Font = New System.Drawing.Font("Bookman Old Style", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_pic.Location = New System.Drawing.Point(795, 357)
        Me.btn_pic.Name = "btn_pic"
        Me.btn_pic.Size = New System.Drawing.Size(160, 38)
        Me.btn_pic.TabIndex = 9
        Me.btn_pic.Text = "Select Photo"
        Me.btn_pic.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Khaki
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(207, 398)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 20)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Product ID:"
        '
        'txt_id
        '
        Me.txt_id.BackColor = System.Drawing.Color.White
        Me.txt_id.Location = New System.Drawing.Point(202, 421)
        Me.txt_id.Name = "txt_id"
        Me.txt_id.ReadOnly = True
        Me.txt_id.Size = New System.Drawing.Size(105, 26)
        Me.txt_id.TabIndex = 11
        '
        'txt_name
        '
        Me.txt_name.BackColor = System.Drawing.Color.White
        Me.txt_name.Location = New System.Drawing.Point(313, 421)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(436, 26)
        Me.txt_name.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Khaki
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(456, 398)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(127, 20)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Product Name:"
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(755, 421)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(107, 26)
        Me.txt_price.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Khaki
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(782, 398)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Price:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Khaki
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(956, 398)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 20)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Material:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Khaki
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(266, 462)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 20)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Style:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Khaki
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(478, 462)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 20)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Ships From:"
        '
        'txt_quantity
        '
        Me.txt_quantity.Location = New System.Drawing.Point(678, 485)
        Me.txt_quantity.Name = "txt_quantity"
        Me.txt_quantity.Size = New System.Drawing.Size(139, 26)
        Me.txt_quantity.TabIndex = 23
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Khaki
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(708, 462)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 20)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Quantity:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Khaki
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(928, 460)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(119, 20)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "Product Type:"
        '
        'cmb_type
        '
        Me.cmb_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_type.FormattingEnabled = True
        Me.cmb_type.Location = New System.Drawing.Point(822, 483)
        Me.cmb_type.Name = "cmb_type"
        Me.cmb_type.Size = New System.Drawing.Size(316, 28)
        Me.cmb_type.TabIndex = 25
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'cmb_material
        '
        Me.cmb_material.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_material.FormattingEnabled = True
        Me.cmb_material.Location = New System.Drawing.Point(868, 421)
        Me.cmb_material.Name = "cmb_material"
        Me.cmb_material.Size = New System.Drawing.Size(273, 28)
        Me.cmb_material.TabIndex = 26
        '
        'cmb_style
        '
        Me.cmb_style.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_style.FormattingEnabled = True
        Me.cmb_style.Location = New System.Drawing.Point(202, 485)
        Me.cmb_style.Name = "cmb_style"
        Me.cmb_style.Size = New System.Drawing.Size(177, 28)
        Me.cmb_style.TabIndex = 27
        '
        'cmb_ships_from
        '
        Me.cmb_ships_from.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_ships_from.FormattingEnabled = True
        Me.cmb_ships_from.Location = New System.Drawing.Point(384, 485)
        Me.cmb_ships_from.Name = "cmb_ships_from"
        Me.cmb_ships_from.Size = New System.Drawing.Size(289, 28)
        Me.cmb_ships_from.TabIndex = 28
        '
        'frm_insert_products_a174559
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1153, 574)
        Me.Controls.Add(Me.cmb_ships_from)
        Me.Controls.Add(Me.cmb_style)
        Me.Controls.Add(Me.cmb_material)
        Me.Controls.Add(Me.cmb_type)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txt_quantity)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_id)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btn_pic)
        Me.Controls.Add(Me.txt_pic_path)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.product_pic)
        Me.Controls.Add(Me.btn_insert)
        Me.Controls.Add(Me.lbl_instruction)
        Me.Controls.Add(Me.grd_products)
        Me.Controls.Add(Me.lbl_insert_new_products)
        Me.Controls.Add(Me.btn_close)
        Me.MaximizeBox = False
        Me.Name = "frm_insert_products_a174559"
        Me.Text = "SENORITA FASHIONS-INSERT PRODUCTS"
        CType(Me.grd_products, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.product_pic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_close As Button
    Friend WithEvents lbl_insert_new_products As Label
    Friend WithEvents grd_products As DataGridView
    Friend WithEvents lbl_instruction As Label
    Friend WithEvents btn_insert As Button
    Friend WithEvents product_pic As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_pic_path As TextBox
    Friend WithEvents btn_pic As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_id As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_price As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_quantity As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents cmb_type As ComboBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents cmb_material As ComboBox
    Friend WithEvents cmb_style As ComboBox
    Friend WithEvents cmb_ships_from As ComboBox
End Class
