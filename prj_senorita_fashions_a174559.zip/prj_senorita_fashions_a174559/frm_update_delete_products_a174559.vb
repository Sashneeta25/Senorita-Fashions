﻿Imports System.ComponentModel

Public Class frm_update_delete_products_a174559
    Dim current_code As String
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_update_delete_products_a174559_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cmb_material.DataSource = run_select("select FLD_MATERIAL from TBL_PRODUCTS_A174559 GROUP BY FLD_MATERIAL")
        cmb_material.DisplayMember = "FLD_MATERIAL"
        cmb_style.DataSource = run_select("select FLD_STYLE from TBL_PRODUCTS_A174559 GROUP BY FLD_STYLE")
        cmb_style.DisplayMember = "FLD_STYLE"
        cmb_ships_from.DataSource = run_select("select FLD_SHIPS_FROM from TBL_PRODUCTS_A174559 GROUP BY FLD_SHIPS_FROM")
        cmb_ships_from.DisplayMember = "FLD_SHIPS_FROM"
        cmb_type.DataSource = run_select("select FLD_TYPE from TBL_PRODUCTS_A174559 GROUP BY FLD_TYPE")
        cmb_type.DisplayMember = "FLD_TYPE"

        refresh_grid()

        get_current_code()

    End Sub
    Private Sub refresh_grid()
        grd_products.DataSource = run_select("select * from TBL_PRODUCTS_A174559")

    End Sub

    Private Sub get_current_code()

        Dim current_row As Integer = grd_products.CurrentRow.Index

        current_code = grd_products(0, current_row).Value

        txt_id.Text = current_code
        txt_name.Text = grd_products(1, current_row).Value
        txt_price.Text = grd_products(2, current_row).Value
        cmb_material.Text = grd_products(3, current_row).Value
        cmb_style.Text = grd_products(4, current_row).Value
        cmb_ships_from.Text = grd_products(5, current_row).Value
        txt_quantity.Text = grd_products(6, current_row).Value
        cmb_type.Text = grd_products(7, current_row).Value


    End Sub

    Private Sub grd_products_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd_products.CellClick
        get_current_code()
    End Sub
    Private Sub txt_name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_name.KeyPress
        If Not Char.IsLetter(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) And Not Char.IsWhiteSpace(e.KeyChar) Then
            btn_update.Enabled = False
            MessageBox.Show("Please enter a valid product name. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_name.ClearUndo()
        ElseIf Char.IsLetter(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If txt_name.Text = "" Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_name_Validating(sender As Object, e As CancelEventArgs) Handles txt_name.Validating
        If (txt_name.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_name_TextChanged(sender As Object, e As EventArgs) Handles txt_name.TextChanged
        If (txt_name.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_price_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_price.KeyPress
        If Not Char.IsDigit(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) And Not Char.IsPunctuation(e.KeyChar) Then
            btn_update.Enabled = False
            MessageBox.Show("Please enter a valid price value of digits ONLY. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_price.ClearUndo()
        ElseIf Char.IsDigit(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If (txt_price.Text = "") Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_price_Validating(sender As Object, e As CancelEventArgs) Handles txt_price.Validating
        If (txt_price.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_price_TextChanged(sender As Object, e As EventArgs) Handles txt_price.TextChanged
        If (txt_price.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_quantity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_quantity.KeyPress
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Convert.ToChar(8) Then
            btn_update.Enabled = False
            MessageBox.Show("Please enter a valid quantity of digits ONLY. Other characters are NOT ACCEPTED")
            e.Handled = True
            MessageBox.Show("You've entered character that is not accepted. Please backspace and enter a valid character ")
            txt_price.ClearUndo()
        ElseIf Char.IsNumber(e.KeyChar) And e.KeyChar = Convert.ToChar(8) Then
            If (txt_quantity.Text = "") Then
                btn_update.Enabled = False
            Else
                btn_update.Enabled = True
            End If
        End If
    End Sub
    Private Sub txt_quantity_Validating(sender As Object, e As CancelEventArgs) Handles txt_quantity.Validating
        If (txt_quantity.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub txt_quantity_TextChanged(sender As Object, e As EventArgs) Handles txt_quantity.TextChanged
        If (txt_quantity.Text = "") Then
            btn_update.Enabled = False
        Else
            btn_update.Enabled = True
        End If
    End Sub
    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        run_command("update TBL_PRODUCTS_A174559 set FLD_PRODUCT_NAME ='" & txt_name.Text & "', FLD_PRICE =" & txt_price.Text & ", FLD_MATERIAL ='" & cmb_material.Text & "', FLD_STYLE ='" & cmb_style.Text & "', FLD_SHIPS_FROM ='" & cmb_ships_from.Text & "', FLD_QUANTITY =" & txt_quantity.Text & ", FLD_TYPE = '" & cmb_type.Text & "'  where FLD_PRODUCT_ID= '" & current_code & "'")

        refresh_grid()
        get_current_code()
    End Sub
    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click

        Beep()
        Dim delete_confirmation = MsgBox(" Are you SURE you would like to delete the product " & current_code & "?", MsgBoxStyle.YesNo)

        If delete_confirmation = MsgBoxResult.Yes Then

            Try

                My.Computer.FileSystem.DeleteFile(Application.StartupPath & "\pictures\" & txt_id.Text & ".jpg")

            Catch ex As Exception

                Beep()
                MsgBox("There is a Mistake in action requested as shown below: " & vbCrLf & vbCrLf & ex.Message)
                'refresh_grid()

            End Try
            run_command("delete from TBL_PRODUCTS_A174559 where FLD_PRODUCT_ID = '" & current_code & "'")
            Beep()
            MsgBox("The product " & current_code & " has been successfully deleted")

            refresh_grid()
            get_current_code()
        End If
        refresh_grid()
    End Sub
End Class